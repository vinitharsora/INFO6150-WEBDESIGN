Assignment 7


1.	Create 4 pages using react components and react-router (Home, About-us, Jobs, Contact) as shown in the lab. Make sure to follow separate folder structure for every component.
2.	Add a card component on each page giving detail about each page. (Similar to the"complex_component_single.htm" example shown in the class and in folder react scripts uploaded in files). Use react map() to create dynamic component at least on one of the page. 
3.	Feel free to use CSS and some additional text to make pages pretty. 
4.	Upload the assignment to Canvas NOT to GIT 


All points covered

