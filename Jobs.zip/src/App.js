import React from 'react';
import NavbarComp from './components/Layout/NavbarComp';

function App() {
  return (
    <div className="App">
      <NavbarComp />
    </div>
  );
}

export default App;
